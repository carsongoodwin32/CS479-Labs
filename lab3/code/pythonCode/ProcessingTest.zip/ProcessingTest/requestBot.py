# Create a new text file named 'output.txt' and write 'Hello, World!' to it
with open('output.txt', 'w') as file:
    file.write('Hello, World!')

# Script exits here
